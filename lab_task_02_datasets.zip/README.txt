Datasets for ANN Lab Task 02 (Logistic Regression)

1. nyc-east-river-bicycle-counts.csv  (210 rows x 11 columns, same format as the notebook)
2. bank_marketing_part1_Data.csv      (210 rows x 7 columns, same format as the notebook)

NOTE: These are sample/practice datasets generated to match the structure of the
originals. The first 5 rows of each file are the real rows shown in the PDF;
the remaining rows are synthetic. Do not present them as the official data.
